export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  description: string;
  category: 'hoodies' | 't-shirts' | 'sweatshirts' | 'mugs';
  image: string;
  graphicImage: string;
  tagline?: string;
  features: string[];
  isSoldOutSoon?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'clue-hoodie',
    name: 'The Clue Hoodie',
    price: 89,
    originalPrice: 120,
    description: "Engineered for the loud, the restless, and the neurodivergent rebels. This isn't just a hoodie; it's armor for the sonic landscape. Heavy-weight construction with a graphic that screams as loud as you do.",
    category: 'hoodies',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAnlEsf3GD3bMdK6vbST6NIGrRX0elqsD1F7UeQsptXIT0XgwLoJW0mbJsFGSkKAfNhjzr0jjqx0oKQN7O3rUSu5hT324eTNViA_ri9BwYPoD7p29dhwiNSFqcOY0okcCt1mQkNgc_63AhUgJcXiEhR3DyiJVhDzeesc7MD3G83g3Qh_bW0KJ_BTBrOXeANBi8z47zenq-dEbHi5D_8KRT0BJYQxh9CifGUq9i27vu7csqqVgndT2XzUCqt7uR21me1sicyQOOLvcsW',
    graphicImage: 'https://lh3.googleusercontent.com/aida/ADBb0uhqFiuJPHMW9uUZQKFdX2gtLMWBrZ-oANgqDNq6OeeV30q-O97PMb2idSfGqZg52i_TDE8msiPcCiw8Kf9U3i_v5K3LIThdwlOLj-9MXAjp0SFXHdmndHDmkNfWf3QZ8sCtRw3c7zjyhDYoPPcFK6Pp8XJVJ3uicaf1FECZq8Mjw9Aywb2_UQQgQ1DRek3fI4b57RkSeZOKzvmwSJjktbcdfKq1s0cTeTwn7EfsQU0INm-zMVJnsZcHJX7rIhoiPj96WvoVXht_I4I',
    tagline: '"LATE DIAGNOSIS... BUT THERE WERE CLUES"',
    features: ['Double-Lined Hood', 'Reinforced Stitching', 'High-Voltage Print'],
    isSoldOutSoon: true
  },
  {
    id: 'shredder-tee',
    name: 'The Shredder Tee',
    price: 35,
    description: "Raw energy unleashed. A classic fit for those who live life at 180bpm. Soft cotton, hard graphic.",
    category: 't-shirts',
    image: 'https://lh3.googleusercontent.com/aida/ADBb0uiEdzjgPvuLBQFKXCkAN-F7f-3mLUeDKVas95e0XoORxom7Tuh5pAXYBo8laaN6ufda2I1IrF9KgGCPN78XJRdueu-FaelBdfptgzGdcyUGNhop2zsC6LLdRZ1AiO_MyjYIad2c4lvtogCvozcSPP3ELDAoxq6Vv1gnXgfDFUuJGQZKekWBewfwNy8BTgZpByX2aGNj36X3Txn_05TayXBP6uuOBpjUhmwXqyeYoK9uVvriyaj7szv9rCqmNAni7JiIHW33Lx0OWNw',
    graphicImage: 'https://lh3.googleusercontent.com/aida/ADBb0uiEdzjgPvuLBQFKXCkAN-F7f-3mLUeDKVas95e0XoORxom7Tuh5pAXYBo8laaN6ufda2I1IrF9KgGCPN78XJRdueu-FaelBdfptgzGdcyUGNhop2zsC6LLdRZ1AiO_MyjYIad2c4lvtogCvozcSPP3ELDAoxq6Vv1gnXgfDFUuJGQZKekWBewfwNy8BTgZpByX2aGNj36X3Txn_05TayXBP6uuOBpjUhmwXqyeYoK9uVvriyaj7szv9rCqmNAni7JiIHW33Lx0OWNw',
    features: ['100% Organic Cotton', 'Side-Seamed', 'Screen Printed']
  },
  {
    id: 'sonic-inferno-mug',
    name: 'Sonic Inferno Mug',
    price: 24,
    description: "For the morning static. Keep your caffeine as hot as the pit.",
    category: 'mugs',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA_mmK61ozEvapvG7lCf6Q_gZdt04nrL_2FXiuDTIYwYUpkbSM39_6KgbWQgYN7Dhjq3QcYlQM0bTZtjVD9hDbhXsgz2ow_0FAhYkH50Pbq-73wQV8nsI3mNtcIUJybaK3CaA8zJBvJPWxUfUjDKFx-I5jZd3_e3Wbk0d35z5OVWj7UgSTrTYYQznNPRfxAYjucdk_GGMPDnF9vqO7jAYmLih1aFYxpxhtb5sUS9Ukx8o9emsm33j_MYOA71_czz454IZYhsEtyMdKL',
    graphicImage: 'https://lh3.googleusercontent.com/aida/ADBb0ujv8VzTTrPWjBtBMF-_HXQd8cu4cxMPJ1sOikI5Mvgct-uZOWIJ79knZ9RtIkHd0u-ydDUXlsDvt_lHv64MCOIlK9hB-085Zgx-USkupBC-qDQIoAwQfzW8XPBgd5nHoDXK46tVV9KhkvjPEAricr9BGkdRjrx9K92xHJTqSVFwJN4bKJDh51M57kDfXGX1wkL2Ak1iOXNDoIatxGbyUgcuHEAaw-uePD926Tnnu4bxn3UJt_p-CtUa5rMkIWTLo6XaUy0kpmvAjw',
    features: ['Ceramic', 'Dishwasher Safe', '11oz']
  }
];
