import React from 'react';
import { ShoppingCart, User, Menu, X } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { useCart } from '../lib/CartContext';

export default function Navbar() {
  const { totalItems, setIsCartOpen } = useCart();

  return (
    <nav className="fixed top-0 w-full z-50 glass-effect border-b border-outline-variant/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl md:text-3xl font-black italic text-primary-container tracking-tighter font-headline uppercase">
          ADHD Squirrel
        </Link>
        
        <div className="hidden md:flex items-center gap-8">
          {['Hoodies', 'T-Shirts', 'Sweatshirts', 'New Drop'].map((item) => (
            <Link
              key={item}
              to={`/category/${item.toLowerCase().replace(' ', '-')}`}
              className="font-headline uppercase tracking-tighter font-bold text-primary hover:text-secondary-container transition-all hover:scale-105 duration-200"
            >
              {item}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-4 text-primary">
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative hover:scale-110 transition-transform active:scale-95 p-2"
          >
            <ShoppingCart size={24} />
            {totalItems > 0 && (
              <span className="absolute top-0 right-0 bg-secondary-container text-black text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-surface">
                {totalItems}
              </span>
            )}
          </button>
          <button className="hover:scale-110 transition-transform active:scale-95 p-2">
            <User size={24} />
          </button>
          <button className="md:hidden hover:scale-110 transition-transform active:scale-95 p-2">
            <Menu size={24} />
          </button>
        </div>
      </div>
    </nav>
  );
}
