import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { PRODUCTS } from '../types';
import { ArrowRight, Layers, DraftingCompass, Bolt, ShoppingBag } from 'lucide-react';
import { cn } from '../lib/utils';
import { useCart } from '../lib/CartContext';

export default function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const product = PRODUCTS.find(p => p.id === id) || PRODUCTS[0];
  const [selectedSize, setSelectedSize] = useState('L');
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    setIsAdding(true);
    addToCart(product, selectedSize);
    setTimeout(() => setIsAdding(false), 1000);
  };

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24">
        {/* Product Image Section */}
        <div className="lg:col-span-7 relative">
          <div className="relative w-full aspect-[4/5] bg-surface-container-low overflow-hidden group">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {/* Graphic Overlay */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/3 opacity-90 pointer-events-none mix-blend-multiply">
              <img src={product.graphicImage} alt="Graphic" className="w-full h-auto" />
            </div>
            
            <div className="absolute bottom-8 left-0 bg-primary-container text-white px-6 py-3 font-headline font-black italic text-2xl -rotate-2 z-10 uppercase">
              SONIC INFERNO DROP
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <div className="bg-surface-container h-64 overflow-hidden">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC-zE0yt9RUjdLg66TWgH110brOTVaTgDZZFClLbQ9u-FroDxDIzD734YQRzH9NMnhdM85DEoKLJRov60BsyMtFqc4z61G5ZuKDlZ5_P2LBXtthIDXtB44saoapRyoDaBBKNDoxujDkhkCsahDK5shXEZduCGW-KTMkqUC2McUNDeQ3QVlW4c4D4d4NpcCJifr2RIkwshP73OKmy2Yfjwh0uKM-SsqzAh7Omm3Da_ZsRAaZ6mKogE7EEDbG3Rk7Y_d2wC1akVkCo_3o"
                alt="Texture"
                className="w-full h-full object-cover grayscale contrast-125"
              />
            </div>
            <div className="bg-surface-container h-64 mt-12 overflow-hidden">
              <img
                src={product.graphicImage}
                alt="Detail"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Product Details Section */}
        <div className="lg:col-span-5 flex flex-col gap-8 sticky top-32 h-fit">
          <div>
            <span className="font-headline text-secondary-container tracking-widest uppercase text-sm mb-2 block">
              Premium Apparel — 001
            </span>
            <h1 className="font-headline text-5xl md:text-7xl font-black uppercase tracking-tighter leading-[0.9] text-white">
              {product.name.split(' ').slice(0, 2).join(' ')} <br />
              <span className="text-primary-container">{product.name.split(' ').slice(2).join(' ')}</span>
            </h1>
          </div>

          <div className="flex items-baseline gap-4">
            <span className="font-headline text-4xl font-bold text-white">${product.price.toFixed(2)}</span>
            {product.originalPrice && (
              <span className="font-headline text-outline line-through text-xl">${product.originalPrice.toFixed(2)}</span>
            )}
          </div>

          <p className="font-body text-outline text-lg leading-relaxed max-w-md">
            {product.description}
          </p>

          {/* Features Bento */}
          <div className="grid grid-cols-1 gap-2 mt-4">
            {[
              { label: 'Double-Lined Hood', icon: <Layers size={20} /> },
              { label: 'Reinforced Stitching', icon: <DraftingCompass size={20} /> },
              { label: 'High-Voltage Print', icon: <Bolt size={20} /> }
            ].map((feature) => (
              <div key={feature.label} className="bg-surface-container px-6 py-4 flex items-center justify-between group hover:bg-surface-container-highest transition-colors">
                <span className="font-headline font-bold uppercase text-lg tracking-tight">{feature.label}</span>
                <span className="text-primary-container group-hover:scale-110 transition-transform">{feature.icon}</span>
              </div>
            ))}
          </div>

          {/* Size Selection */}
          <div className="mt-4">
            <div className="flex justify-between items-center mb-4">
              <label className="font-headline uppercase text-xs tracking-widest text-outline">Select Size</label>
              <button className="text-xs font-headline uppercase text-secondary-container underline underline-offset-4">Size Guide</button>
            </div>
            <div className="flex flex-wrap gap-2">
              {['S', 'M', 'L', 'XL', '2XL'].map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={cn(
                    "w-12 h-12 flex items-center justify-center font-headline font-bold text-lg border transition-colors",
                    selectedSize === size 
                      ? "bg-primary-container border-primary-container text-white" 
                      : "border-outline-variant/20 hover:border-primary text-white"
                  )}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* CTA Button */}
          <button 
            onClick={handleAddToCart}
            disabled={isAdding}
            className={cn(
              "w-full py-6 text-white font-headline font-black uppercase text-2xl tracking-tighter transition-all active:scale-[0.98] duration-100 flex items-center justify-center gap-4",
              isAdding ? "bg-secondary-container" : "bg-primary-container hover:bg-secondary-container"
            )}
          >
            {isAdding ? (
              <>
                ADDED TO HAUL
                <ShoppingBag className="animate-bounce" />
              </>
            ) : (
              <>
                ADD TO CART
                <ArrowRight />
              </>
            )}
          </button>

          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-xs font-headline uppercase tracking-widest text-secondary">
              <span className="w-2 h-2 bg-secondary rounded-full" />
              In Stock & Ready to Ship
            </div>
            <div className="flex items-center gap-2 text-xs font-headline uppercase tracking-widest text-outline">
              <span className="w-2 h-2 bg-outline rounded-full" />
              Free Global Shipping
            </div>
          </div>
        </div>
      </div>

      {/* Technical Specs */}
      <section className="mt-32 bg-surface-container-low py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="font-headline text-5xl font-black uppercase tracking-tighter mb-12 italic text-primary-container">TECHNICAL BREAKDOWN</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { title: 'Heavy Metal Fabric', desc: '450GSM ultra-dense organic cotton fleece. Built to withstand the pit and the street.' },
              { title: 'Chaos-Proof Print', desc: "Industrial screen-print with 'High-Voltage' ink that never fades, flakes, or cracks under pressure." },
              { title: 'Oversized Fit', desc: 'Dropped shoulders and elongated sleeves for that signature distorted silhouette.' }
            ].map((spec) => (
              <div key={spec.title} className="space-y-4 border-l-2 border-primary-container/20 pl-6">
                <h3 className="font-headline font-bold text-2xl uppercase">{spec.title}</h3>
                <p className="font-body text-outline">{spec.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
