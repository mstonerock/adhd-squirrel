import React from 'react';
import { motion } from 'motion/react';
import { Zap, Skull, Flame, Wind } from 'lucide-react';

export default function Manifesto() {
  return (
    <div className="pt-32 pb-20">
      <div className="max-w-4xl mx-auto px-6 space-y-24">
        <header className="text-center space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-block px-4 py-1 bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-[0.4em]"
          >
            THE SONIC INFERNO
          </motion.div>
          <h1 className="font-headline text-7xl md:text-9xl font-black italic uppercase tracking-tighter leading-none">
            THE <span className="fire-gradient-text">MANIFESTO</span>
          </h1>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <h2 className="font-headline text-4xl font-black uppercase italic border-l-4 border-primary pl-6">01. THE STATIC</h2>
            <p className="text-lg text-outline leading-relaxed">
              We don't see distraction. We see a thousand channels playing at once. ADHD Squirrel is the uniform for those who live in the high-frequency static. We don't slow down. We make the world catch up.
            </p>
          </div>
          <div className="space-y-8">
            <h2 className="font-headline text-4xl font-black uppercase italic border-l-4 border-secondary pl-6">02. THE DISRUPTION</h2>
            <p className="text-lg text-outline leading-relaxed">
              Normal is a cage. We are the glitch in the system. Our gear is designed to be loud, disruptive, and unapologetic. If it doesn't make people look twice, it's not ADHD Squirrel.
            </p>
          </div>
          <div className="space-y-8">
            <h2 className="font-headline text-4xl font-black uppercase italic border-l-4 border-primary-container pl-6">03. THE VELOCITY</h2>
            <p className="text-lg text-outline leading-relaxed">
              Life at 180bpm. We build apparel that survives the mosh pit of existence. Heavy-weight fabrics, industrial prints, and silhouettes that move as fast as your thoughts.
            </p>
          </div>
          <div className="space-y-8">
            <h2 className="font-headline text-4xl font-black uppercase italic border-l-4 border-white/20 pl-6">04. THE REVOLUTION</h2>
            <p className="text-lg text-outline leading-relaxed">
              Neurodiversity isn't a condition; it's a superpower. We are building a tribe of restless souls who refuse to be dimmed. Join the chaos. Enter the pit.
            </p>
          </div>
        </div>

        <div className="bg-surface-container p-12 border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
            <Skull className="w-64 h-64" />
          </div>
          <div className="relative z-10 space-y-8">
            <h3 className="font-headline text-5xl font-black uppercase italic tracking-tighter">WE ARE THE <br /><span className="text-primary">SQUIRRELS OF CHAOS.</span></h3>
            <p className="text-xl font-light text-outline max-w-xl">
              "Late diagnosis... but there were clues." We wear our history like armor. We are the loud, the restless, and the neurodivergent rebels.
            </p>
            <div className="flex gap-6">
              <Zap className="text-primary" />
              <Flame className="text-secondary" />
              <Wind className="text-primary-container" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
