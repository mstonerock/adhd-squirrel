import React from 'react';
import { motion } from 'motion/react';
import { PRODUCTS } from '../types';
import { Link, useParams } from 'react-router-dom';
import { cn } from '../lib/utils';
import { ShoppingBag, ArrowRight } from 'lucide-react';

export default function Home() {
  const { category } = useParams();
  const heroProduct = PRODUCTS[0];

  const filteredProducts = category 
    ? PRODUCTS.filter(p => p.category === category.replace('-', ' '))
    : PRODUCTS;

  if (category) {
    return (
      <div className="pt-32 pb-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-6">
          <header className="mb-16">
            <h2 className="font-headline text-xs font-black tracking-[0.3em] text-secondary mb-4 uppercase">CATEGORY // 001</h2>
            <h1 className="font-headline text-6xl md:text-8xl font-black italic tracking-tighter uppercase leading-none">
              THE <span className="fire-gradient-text">{category.replace('-', ' ')}</span>
            </h1>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <Link 
                key={product.id}
                to={`/product/${product.id}`}
                className="group relative bg-surface-container overflow-hidden border border-white/5 hover:border-primary/30 transition-all duration-500"
              >
                <div className="aspect-[4/5] overflow-hidden relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  {product.isSoldOutSoon && (
                    <div className="absolute top-4 left-4 bg-secondary-container text-black px-3 py-1 font-headline font-black italic uppercase text-[10px] z-10">
                      SOLD OUT SOON
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="bg-white text-black px-6 py-3 font-headline font-black uppercase tracking-widest transform translate-y-4 group-hover:translate-y-0 transition-transform">
                      VIEW GEAR
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-headline font-bold text-xl uppercase tracking-tight group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                    <span className="font-headline font-black text-primary text-xl">${product.price}</span>
                  </div>
                  <p className="text-xs text-outline uppercase font-bold tracking-widest">{product.category}</p>
                </div>
              </Link>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="py-32 text-center space-y-6">
              <ShoppingBag className="w-16 h-16 mx-auto opacity-20" />
              <h3 className="font-headline text-3xl font-black uppercase">Nothing here yet</h3>
              <p className="text-outline">The static is still forming. Check back soon for new drops.</p>
              <Link to="/" className="inline-block px-8 py-4 bg-primary-container text-white font-bold uppercase tracking-widest hover:bg-secondary-container transition-colors">
                BACK TO BASE
              </Link>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://lh3.googleusercontent.com/aida/ADBb0ujv8VzTTrPWjBtBMF-_HXQd8cu4cxMPJ1sOikI5Mvgct-uZOWIJ79knZ9RtIkHd0u-ydDUXlsDvt_lHv64MCOIlK9hB-085Zgx-USkupBC-qDQIoAwQfzW8XPBgd5nHoDXK46tVV9KhkvjPEAricr9BGkdRjrx9K92xHJTqSVFwJN4bKJDh51M57kDfXGX1wkL2Ak1iOXNDoIatxGbyUgcuHEAaw-uePD926Tnnu4bxn3UJt_p-CtUa5rMkIWTLo6XaUy0kpmvAjw"
            alt="ADHD Squirrel Band"
            className="w-full h-full object-cover opacity-30 mix-blend-luminosity"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface-container-lowest via-surface-container-lowest/40 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7"
          >
            <h2 className="font-headline text-xs font-black tracking-[0.3em] text-secondary mb-4 uppercase">FORGED IN THE STATIC</h2>
            <h1 className="font-headline text-6xl md:text-8xl lg:text-9xl font-black italic tracking-tighter uppercase mb-6 leading-none">
              THE <span className="fire-gradient-text block">LIMITED</span> DROP
            </h1>
            <p className="text-lg md:text-xl max-w-xl mb-8 font-light text-outline leading-relaxed">
              The Sonic Inferno has arrived. ADHD Squirrel's high-octane gear for the neurospicy revolution. Wear it loud. Wear it fast.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-10 py-5 bg-primary-container text-white font-bold uppercase tracking-widest hover:bg-secondary-container transition-colors duration-300">
                ENTER THE PIT
              </button>
              <div className="flex items-center gap-4 px-6 border border-outline/20 backdrop-blur-sm">
                <span className="font-headline font-black text-secondary-container uppercase">EST. 2024</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
            animate={{ opacity: 1, scale: 1, rotate: 3 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative z-20 shadow-2xl">
              <img
                src={heroProduct.graphicImage}
                alt="ADHD Squirrel Rock Band"
                className="w-full border-4 border-primary/20"
              />
              <div className="absolute -bottom-6 -right-6 bg-secondary-container text-surface px-6 py-2 font-headline font-black italic uppercase text-xl shadow-lg">
                SOLD OUT SOON
              </div>
            </div>
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary-container/20 blur-3xl rounded-full" />
          </motion.div>
        </div>
      </section>

      {/* Product Highlight */}
      <section className="py-24 bg-surface-container-low">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="relative group cursor-pointer"
            >
              <div className="absolute inset-0 bg-primary-container opacity-0 group-hover:opacity-10 transition-opacity" />
              <img
                src={heroProduct.graphicImage}
                alt={heroProduct.name}
                className="w-full relative z-10"
              />
              <div className="absolute top-4 left-4 bg-surface-container-lowest px-4 py-2 border-l-4 border-primary-container z-20">
                <span className="font-headline font-black text-xs text-primary uppercase">CLUE SERIES</span>
              </div>
            </motion.div>

            <div>
              <h3 className="font-headline text-5xl md:text-7xl font-black uppercase tracking-tighter mb-4">{heroProduct.name}</h3>
              <p className="font-headline text-2xl font-black text-secondary-container mb-6 italic uppercase tracking-tight">
                {heroProduct.tagline}
              </p>
              <div className="flex items-center gap-8 mb-8">
                <div className="flex flex-col">
                  <span className="text-3xl font-headline font-black text-secondary-container">02:14:55</span>
                  <span className="text-[10px] uppercase font-black tracking-widest text-outline">TIME TO IMPACT</span>
                </div>
                <div className="h-10 w-[1px] bg-outline/20" />
                <div className="text-primary font-headline font-bold text-2xl tracking-widest">${heroProduct.price.toFixed(2)}</div>
              </div>

              <div className="space-y-6 mb-12">
                {heroProduct.features.map((feature, idx) => (
                  <div key={feature} className={`flex items-start gap-4 p-6 ${idx === 0 ? 'bg-surface-container-highest border-l-2 border-primary-container' : 'bg-surface-container border-l-2 border-outline/20'}`}>
                    <div className="w-6 h-6 flex items-center justify-center text-primary-container">
                      {idx === 0 ? '⚡' : idx === 1 ? '💀' : '🔥'}
                    </div>
                    <div>
                      <h4 className="font-headline font-black text-sm uppercase mb-1">{feature}</h4>
                      <p className="text-sm text-outline">Premium quality built to survive the most violent mosh pits.</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link 
                to={`/product/${heroProduct.id}`}
                className="block w-full text-center py-6 bg-surface-container-highest border-2 border-primary-container text-primary-container font-headline font-black uppercase text-xl hover:bg-primary-container hover:text-white transition-all duration-300 active:scale-95"
              >
                VIEW DETAILS
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Grid Mosaic */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 auto-rows-[300px]">
            <div className="md:col-span-2 md:row-span-2 bg-surface-container relative overflow-hidden group">
              <img
                src="https://lh3.googleusercontent.com/aida/ADBb0ujv8VzTTrPWjBtBMF-_HXQd8cu4cxMPJ1sOikI5Mvgct-uZOWIJ79knZ9RtIkHd0u-ydDUXlsDvt_lHv64MCOIlK9hB-085Zgx-USkupBC-qDQIoAwQfzW8XPBgd5nHoDXK46tVV9KhkvjPEAricr9BGkdRjrx9K92xHJTqSVFwJN4bKJDh51M57kDfXGX1wkL2Ak1iOXNDoIatxGbyUgcuHEAaw-uePD926Tnnu4bxn3UJt_p-CtUa5rMkIWTLo6XaUy0kpmvAjw"
                alt="Shredder"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-surface-container-lowest via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-6 left-6">
                <h4 className="font-headline text-3xl font-black uppercase text-secondary-container leading-none">THE SHREDDER</h4>
                <p className="text-xs font-bold text-outline uppercase tracking-widest mt-2">RAW ENERGY UNLEASHED</p>
              </div>
            </div>
            <div className="bg-surface-container-highest flex items-center justify-center p-8 text-center border-t-4 border-primary-container">
              <div className="font-headline text-4xl font-black italic uppercase leading-none text-primary">STAY<br />WEIRD.</div>
            </div>
            <div className="relative overflow-hidden group bg-surface-container">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA_mmK61ozEvapvG7lCf6Q_gZdt04nrL_2FXiuDTIYwYUpkbSM39_6KgbWQgYN7Dhjq3QcYlQM0bTZtjVD9hDbhXsgz2ow_0FAhYkH50Pbq-73wQV8nsI3mNtcIUJybaK3CaA8zJBvJPWxUfUjDKFx-I5jZd3_e3Wbk0d35z5OVWj7UgSTrTYYQznNPRfxAYjucdk_GGMPDnF9vqO7jAYmLih1aFYxpxhtb5sUS9Ukx8o9emsm33j_MYOA71_czz454IZYhsEtyMdKL"
                alt="Mug"
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all"
              />
            </div>
            <div className="md:col-span-2 bg-primary-container flex flex-col justify-end p-8 group">
              <div className="transform group-hover:-translate-y-2 transition-transform">
                <h4 className="font-headline text-4xl font-black uppercase text-on-primary tracking-tighter">JOIN THE CHAOS</h4>
                <p className="text-on-primary/80 mt-2">Sign up for secret drops and back-stage access.</p>
                <div className="mt-6 flex bg-on-primary/10 p-1">
                  <input
                    type="email"
                    placeholder="YOUR EMAIL"
                    className="bg-transparent border-none text-on-primary placeholder:text-on-primary/50 focus:ring-0 flex-grow font-headline font-bold uppercase px-4"
                  />
                  <button className="bg-on-primary text-primary-container px-6 py-2 font-black uppercase text-sm">JOIN</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Drops */}
      <section className="py-24 bg-surface-container-lowest">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-headline text-xs font-black tracking-[0.3em] text-secondary mb-4 uppercase">CURRENT ROTATION</h2>
              <h3 className="font-headline text-5xl font-black uppercase tracking-tighter italic">FEATURED <span className="text-primary">DROPS</span></h3>
            </div>
            <Link to="/category/hoodies" className="group flex items-center gap-2 font-headline font-bold uppercase text-xs tracking-widest text-outline hover:text-primary transition-colors">
              VIEW ALL GEAR
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRODUCTS.slice(0, 3).map((product) => (
              <Link 
                key={product.id}
                to={`/product/${product.id}`}
                className="group space-y-4"
              >
                <div className="aspect-[4/5] bg-surface-container overflow-hidden relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity mix-blend-overlay" />
                </div>
                <div>
                  <h4 className="font-headline font-bold text-lg uppercase group-hover:text-primary transition-colors">{product.name}</h4>
                  <p className="text-primary font-mono font-bold">${product.price}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
